'use strict';
const header = document.querySelector('header');

window.addEventListener('scroll', () => {
    console.log('Scrolling');
    header.classList.add('hovered');
});

window.addEventListener('load', () => {
    //buttons
    const left = document.querySelector('.btn-left');
    const right = document.querySelector('.btn-right');
    //carousel
    const slider = document.querySelector('.carousel__slide');
    const imgs = document.querySelectorAll('.carousel__slide img');

    //counter

    let counter = 0;
    const stepSize = imgs[0].clientWidth;

    slider.style.transform = `translateX(-${stepSize * counter}px)`;

    right.addEventListener('click', () => {
        if (counter >= imgs.length - 1) counter = -1;
        slider.classList.add('time2Animate');
        counter++;
        slider.style.transform = `translateX(-${stepSize * counter}px)`;
    });

    left.addEventListener('click', () => {
        if (counter <= 0) counter = imgs.length;
        slider.classList.add('time2Animate');
        counter--;
        slider.style.transform = `translateX(-${stepSize * counter}px)`;
    });
    slider.addEventListener('transitionend', (event) => {
        console.log('Конец Анимации');
    });
});
